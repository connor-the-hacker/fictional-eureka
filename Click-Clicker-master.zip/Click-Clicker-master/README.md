# Click-Clicker
An idle game made with python 3.6

# Wiki
There is a wiki available in the Wiki tab in Github

# Download
Download the folder GameFiles and the file PythonIdleGame.py, and run PythonIdleGame.py to start the game.
MAKE SURE YOU HAVE PYTHON 3.6 INSTALLED
You can get the required version of python here: https://www.python.org/ftp/python/3.6.3/python-3.6.3-amd64.exe
